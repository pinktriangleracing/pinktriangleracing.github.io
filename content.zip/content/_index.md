+++
date = '2025-06-28T09:40:40+01:00'
draft = false
title = 'Pink Triangle Racing'
+++

![](Fortuna.jpg)

Welcome to the website home of the Pink Triangle Racing Team.  Come on in, have a look around and get to know the team and find out what it's all [about](about).  Have a read through some of the previous [race reports](race_reports) and once you're excited, check out the [upcoming events](upcoming_events) then find out what you'll need in order to [join the team](join_us), and finally; get in [contact](contact) to find out more!!!

Stay as long or as short as you'd like, everyone's welcome as long as:
- you're excited to get involved in some motorbike racing
- you've typically been riding motorbikes for around a year and ideally have a bit of track experience
- you're likeminded and onbaord with the team being welcoming and inclusive to all





