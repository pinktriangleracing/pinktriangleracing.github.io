+++
date = '2025-06-28T11:15:58+01:00'
draft = false
title = 'Pink Triangle Mountaineering'
+++

![](PTM_4.png)
Pink Triangle Mountaineering provides activities into the UK's mountainous regions, with a focus on activites being open and welcoming to everyone from all backgrounds.  

To find out more, do go and check out their [instagram page](https://www.instagram.com/pinktrianglemountaineering/).
