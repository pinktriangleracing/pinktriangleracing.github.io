+++
date = '2025-06-28T09:49:45+01:00'
draft = true
title = 'Race Reports'
+++

The team has been competing since 2022 and over the years has finished a good number of races, with Sprint and Endurance podium finishes on the results sheets.  Have a read through the race reports to get an idea of how things have gone so far.