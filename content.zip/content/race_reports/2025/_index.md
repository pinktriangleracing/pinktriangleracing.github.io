+++
date = '2025-06-28T09:49:59+01:00'
draft = false
title = '2025 Race Season'
+++

The 2024 season was a great success, new riders introduced to the Freetech Endurance championship, other riders returning back to it; all great fun.  Though, the organisational side of running the team did take its toll.  As such, it's been decided to take stock for a year and reduce the team size back to a single bike per race, and to also be a touch more selective about which events to attend as calendar commitments allow.

Having said this, with the introduction of [MERS UK](https://www.mers-uk.co.uk/) on the potential calendar, it's been decided to bring a KTM RC390 into the race fleet, and to take things up a notch and get into the mix with some 500cc racing.

As the 2025 season progresses, keep up with the team's endeavours with the reports below: