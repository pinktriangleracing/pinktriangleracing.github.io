+++
date = '2025-06-28T09:53:51+01:00'
draft = false
title = '2024 Race Season'
+++

After a sucessful 2023 season, a decision was made to take on the challenge of running 2 bikes throughout the 2024 season.  With two bikes, this means more riders could come and enjoy the fun, and with fixed costs being split between more riders, costs were kept even lower for the season.